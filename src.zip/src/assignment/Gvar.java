package assignment;

public class Gvar {
	public static int id;
	public static String username;
}
